$(document).ready(function () {
  $.getJSON('/addsong', function(data){
  });
});
