#!/bin/bash
i=1
mkdir lyricdatabase
while IFS='' read -r line || [[ -n "$line" ]]; do
    echo "$line$i"
    curl -s $line | ./headerscript > lyricdatabase/file$i
    curl -s $line | ./lyricsscript >> lyricdatabase/file$i
    let "i+=+1"
done < "$1"